=== Clickbank Ads ===
Contributors: Kevin Davies, Ted Perksy
Tags: clickbank, ads, sidebar, widget
Requires at least: 2.8
Tested up to: 2.9.1
Stable tag: trunk

Allows you to Google adsense style clickbank ads to your site.


== Description ==

This plugin allows you to display clickbank ads on your website similar to google ads.


== Installation ==

1. Create a directory called 'clickbankads' in your plugins directory and copy the clickbank ads files into it.
2. Activate the plugin.
3. Configure your settings via Appearance -> Widgets. Be sure to enter your clickbank id. 


== Feedback and Support ==

Visit clickbankads.net.


== Plugin History ==

**Latest Release:** January 28, 2010


* 1.0 - Initial release

