<?php
/*
Plugin Name: clickbankads
Plugin URI: http://clickbankads.net
Description: Add clickbank ads to your site
Version: 1.0
License: GPL
Author: Kevin Davies
Author URI: http://gobiz.co.nz
*/
$version = '1.0';

function setupActivation() {
		
     function get_and_delete_option($setting) { $v = get_option($setting); delete_option($setting); return $v; }
		
	// check for previously installed version
	if (get_option('clickbankAds_clickbankAdsId')) {
		$settings = array(
	        get_and_delete_option('clickbankAds_width'),
		get_and_delete_option('clickbankAds_height'),
		get_and_delete_option('clickbankAds_orientation'),
		get_and_delete_option('clickbankAds_numberOfAds'),
		get_and_delete_option('clickbankAds_secs'),
		get_and_delete_option('clickbankAds_clickbankId')
    	   );
  	   update_option('clickbankAds_settings', $settings);
	}
	else{
	  update_option('clickbankAds_settings', array('clickbankAds_width'=>'180', 'clickbankAds_height'=>'280', 'clickbankAds_secs'=>'60', 'clickbankAds_numberOfAds'=>'3'));
	}
		
	// update version number
	if (get_option('clickbankAds_version') != $version){
		update_option('clickbankAds_version', $version);
	}

}
	
	
function getSettings() {
			
    if (!get_option('clickbankAds_settings')) setupActivation();
			
    $settings = array(
	    	        'clickbankAds_width' => '500',
		        'clickbankAds_height' => '500',
			'clickbankAds_orientation' => '',
			'clickbankAds_numberOfAds' => '',
			'clickbankAds_secs' => '60',
			'clickbankAds_clickbankId' => '',);
			if (get_option('clickbankAdsS_settings')){
			    $settings = array_merge($settings, get_option('clickbankAds_settings'));
                        }

     return $settings;

}

function printSettingsPage() {
     $settings = getSettings();
     if (isset($_POST['save_clickbankAds_settings'])) {
	  $settings = array_merge($settings, $_POST);
	  foreach ($settings as $name => $value) {
		$settings[$name] = $_POST[$name];
	 }
	 update_option('clickbankAds_settings', $settings);
	 echo '<div class="updated"><p>Clickbank Ads settings saved!</p></div>';
     }
     if (isset($_POST['reset_clickbankAds_settings'])) {
	delete_option('clickbankAds_settings');
	echo '<div class="updated"><p>Clickbank Ads settings restored to default!</p></div>';
     } ?>
                        <div class="wrap">
          	           <h2>Clickbank Ads Settings</h2>
	                      <form method="post">
                                 <fieldset>
                                    <ul> <?php
                                         include ("clickbankads-settingspage.php"); ?>
                                         <li>
    		   	                      <input type="submit" name="reset_clickbankAds_settings" value="<?php _e('Reset') ?>" />
			                      <input type="submit" name="save_clickbankAds_settings" value="<?php _e('Save Settings') ?>" class="button-primary" />
                                         </li>
                                   </ul>
                                </fieldset>
                            </form>
                       </div><?php
}

function setupSettingsPage() {
     if (function_exists('add_options_page')) {
	add_options_page('ClickbankAds Settings', 'ClickbankAds', 8, basename(__FILE__),  'printSettingsPage');
     }
}

function setupWidget() {

     if (!function_exists('register_sidebar_widget')) return;
	function widget_clickbankAds($args) {
	     displayClickbankAds();
     }
	
     function widget_clickbankAds_control() {
             $settings = get_option('clickbankAds_settings');			        
	     $settings = empty($settings)?array():$settings;
	     if (isset($_POST['clickbankAds-submit'])) {
		 $settings = array_merge($settings, $_POST);
                 update_option('clickbankAds_settings', $settings);
             }
             include ("clickbankads-settingspage.php"); ?>
                <input type="hidden" name="clickbankAds-submit" />
                <?php
      }
      register_sidebar_widget('clickbankAds', 'widget_clickbankAds');
      register_widget_control('clickbankAds', 'widget_clickbankAds_control');

}

// For future releases
//add_action( 'admin_menu',  'setupSettingsPage' );
add_action( 'plugins_loaded', 'setupWidget');
register_activation_hook( __FILE__, 'setupActivation');

function displayClickbankAds() {
     $settings = get_option('clickbankAds_settings');
     $clickbankId = $settings['clickbankAds_clickbankId']; 
     $orientation = $settings['clickbankAds_orientation'];
     $orientation = empty($orientation)?'v':$orientation;
     $secs = empty($settings['clickbankAds_secs'])?60:$settings['clickbankAds_secs'];
     $height = empty($settings['clickbankAds_height'])?'500':$settings['clickbankAds_height'];
     $width = empty($settings['clickbankAds_width'])?'600':$settings['clickbankAds_width'];
     $numberOfAds = empty($settings['clickbankAds_numberOfAds'])?'3':$settings['clickbankAds_numberOfAds'];
     $pathToClientFile = "wp-content/plugins/clickbankads"; 
     $clickbankId = empty($clickbankId)?'clbnkfy':$clickbankId;
?>
     <div id="cba_container">
          <script src="<?php echo $pathToClientFile; ?>/cbads.php?u=<?php echo $clickbankId; ?>&o=<?php echo $orientation; ?>&s=<?php echo $secs; ?>&h=<?php echo $height; ?>&w=<?php echo $width; ?>"></script>
          <div><a href="http://www.clickbankads.net">Ads by clickbankads.net</a></div>
     </div>

<?php
}

?>