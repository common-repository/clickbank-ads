<?php

if(isset($_POST['body']) && isset($_POST['title'])){
  
function rankContent($title, $content, $numberOfWordsToReturn){

	$content = str_replace('  ', ' ', str_replace('<', ' ', str_replace('>', '  ', str_replace('</',' ', strtolower($content)))));
	$clickbankWords = array('jobs','finance','home business','entrepeneur','self employment','education',
				'resume','management','debt','employment','money','graphics','email','design','domains',
				'programming','browsers','hosting','network','administration','computing','internet',
				'estate','improvement','geneology','family','marriage','pets','students','school',
				'crafts','parenting','garden','cooking','recipes','remedies','remedy','diet','health',
				'nutrition','beauty','fitness','spiritual','women','womens','addiction','men','mens',
				'web','promotion','management','industrial','publishing','publish','business', 'science',
				'philosophy','religion','law','investigation','travel','shopping','love','romance','sex',
				'politics','government','language','charity','outdoor','extreme','horseracing',
				'sports','gambling','training','casino','sports-picks','golf','autos','cars','recreation',
				'hobbies','magic','humor','music','tarot','games','screensavers','psychics','novels',
				'ebooks','astrology','fun','entertainment','marketing','ezines','how tos','consulting',
				'classifieds','advertising','submitters','banners','ads', 'auctions','auction','beauty',
				'registry','registration','tattoos','cash','fat','weightloss','PC','video','DVD',
				'downloads','forex','school','music','instruments','christmas','holidays',
				'stomach','mp3','audio','tv','channels','games','gaming','wow','television','pets',
				'animals','ai','secret','secrets','green','restaurant','PPC','free','muscle','protection',
				'link','links','driving','hearing','articles','article','healthcare','tips','satellite',
				'clickbank','adsense','google','SEO','directories','paypal','blogs','software','wordpress',
				'training');


	$words = explode(" ", $content);
	$rankedWords = array();

	while(list($i,$word)=each($words)){
		if(in_array($word, $clickbankWords)){
			$rankedWords[$word] = isset($rankedWords[$word])?$rankedWords[$word] +1:1;
		}
	}

	arsort($rankedWords);

	$ret = "";
	$rankedWords = array_keys($rankedWords);
	for($i=0;$i<$numberOfWordsToReturn;$i++){
	    if(!empty($rankedWords[$i])){
		$ret[] = $rankedWords[$i];
            }
	}
	
	return implode(',',$ret);
}

echo rankContent($_POST['title'], $_POST['body'], 3);

}
else{ 

header("Content-type:  text/javascript");

$cbid = $_GET['u'];

if(!isset($srl) || empty($srl)){
	$srl = isset($_GET['srl'])?$_GET['srl']:'0';
}

if(!isset($container) || empty($container)){
	$container = isset($_GET['cid'])?$_GET['cid']:'cba_container';
}

if(!isset($orientation) || empty($orientation)){
	$orientation = isset($_GET['o'])?$_GET['o']:'v';
}

if(!isset($height) || empty($height)){
	if(isset($_GET['h'])){
	      $height = $_GET['h'];
          }
	else{
	      $height = $orientation=='v'?'200':'90';
          }
}

if(!isset($width) || empty($width)){
	$width = isset($_GET['w'])>0?$_GET['w']:$orientation=='v'?'280':'468';
	if(isset($_GET['w'])){
	      $width = $_GET['w'];
          }
	else{
	      $width = $orientation=='v'?'280':'468';
          }
}

if(!isset($numberOfAdPanels) || empty($numberOfAdPanels)){  
	$numberOfAdPanels = isset($_GET['n']) &&$_GET['n'] > 0 ?$_GET['n']:3;
}
if(!isset($delay) || empty($delay)){
	$delay = isset($_GET['s']) && $_GET['s'] > 0?$_GET['s']:5;
}




?>

function loadIFrame(keywords){

       var firstTime = false;

       if(document.getElementById('<?php echo $container; ?>adPanel1')){
            var currentAdPanel = document.getElementById('<?php echo $container; ?>adPanel1');
	   currentAdPanel.parentNode.removeChild(currentAdPanel);  
            var nextAdPanel = document.getElementById('<?php echo $container; ?>adPanel2');
	   nextAdPanel.setAttribute('id','<?php echo $container; ?>adPanel1');
	   nextAdPanel.style.display = 'block';
       }
       else{
            var iFrame<?php echo $container; ?> = document.createElement('IFRAME');
            iFrame<?php echo $container; ?>.setAttribute('id', '<?php echo $container; ?>adPanel1');
            iFrame<?php echo $container; ?>.setAttribute('width', '<?php echo $width; ?>');
            iFrame<?php echo $container; ?>.setAttribute('height', '<?php echo $height; ?>');
            iFrame<?php echo $container; ?>.setAttribute('frameborder', '0');
            iFrame<?php echo $container; ?>.setAttribute('scrolling', 'no');
  	   document.getElementById('<?php echo $container; ?>').innerHTML="";
            document.getElementById('<?php echo $container; ?>').appendChild(iFrame<?php echo $container; ?>); 
            firstTime = true;
            iFrame<?php echo $container; ?>.setAttribute('src', 'http://www.clickbankads.net/cba.fr.src.php?o=<?php echo $orientation; ?>&u=<?php echo $cbid; ?>&k='+keywords+'&h=<?php echo $height; ?>&w=<?php echo $width; ?>&n=<?php echo $numberOfAdPanels; ?>&s=<?php echo $delay; ?>');     
       }
  
            var iFrame2<?php echo $container; ?> = document.createElement('IFRAME');
            iFrame2<?php echo $container; ?>.setAttribute('id', '<?php echo $container; ?>adPanel2');
            iFrame2<?php echo $container; ?>.setAttribute('width', '<?php echo $width; ?>');
            iFrame2<?php echo $container; ?>.setAttribute('height', '<?php echo $height; ?>');
            iFrame2<?php echo $container; ?>.setAttribute('frameborder', '0');
            iFrame2<?php echo $container; ?>.setAttribute('scrolling', 'no');
            document.getElementById('<?php echo $container; ?>').appendChild(iFrame2<?php echo $container; ?>); 
	   iFrame2<?php echo $container; ?>.style.display = 'none';
            iFrame2<?php echo $container; ?>.setAttribute('src', 'http://www.clickbankads.net/cba.fr.src.php?o=<?php echo $orientation; ?>&u=<?php echo $cbid; ?>&k='+keywords+'&h=<?php echo $height; ?>&w=<?php echo $width; ?>&n=<?php echo $numberOfAdPanels; ?>&s=<?php echo $delay; ?>');     

       if(document.getElementById('<?php echo $container; ?>recipLink')){
	    var recipLink = document.getElementById('<?php echo $container; ?>recipLink');
             recipLink.parentNode.removeChild(recipLink);
       }
       
       var link = document.createElement('DIV');
       link.setAttribute('id', '<?php echo $container; ?>recipLink');
       link.innerHTML = "<a style='font-size:12px;margin:0 0 0 15px;font-weight:bold;' href='http://www.clickbankads.net'>Ads by clickbankads.net</a>";
       document.getElementById('<?php echo $container; ?>').appendChild(link);

       setTimeout(function(){loadIFrame(keywords, false);}, <?php echo $delay*1000; ?>);

}

function reqCompleteCB(){
  return function(o){
     loadIFrame(o.responseText, true);  
  }
}

function ajaxFunction(requestCompleteCallback, params)
{
	var url = 'http://<?php echo $_SERVER['HTTP_HOST']; ?><?php echo dirname($_SERVER['PHP_SELF']); ?>/cbads.php';
	var xmlhttp;
	if (window.XMLHttpRequest)
  	{
  		// code for IE7+, Firefox, Chrome, Opera, Safari
  		xmlhttp=new XMLHttpRequest();
  	}
	else
  	{
  		// code for IE6, IE5
 		 xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
 	 }
	xmlhttp.onreadystatechange=function()
	{

		if(xmlhttp.readyState==4)
  		{
  			requestCompleteCallback(xmlhttp);
  		}
	}
	xmlhttp.open('POST',url, true);
        xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        xmlhttp.setRequestHeader("Content-length", params.length);
        xmlhttp.setRequestHeader("Connection", "close");
	xmlhttp.send(params);

}

var titleTags = document.getElementsByTagName('title');
var title = titleTags[0]?titleTags[0]:"";
ajaxFunction(reqCompleteCB(),'body='+document.body.innerHTML+'&title='+title);


<?php
}

?>