
                        <li>
                             <label>Clickbank Id</label>
                             <div>
                                 <input type="text" id="clickbankAds_clickbankId" value="<?php echo $settings["clickbankAds_clickbankId"]; ?>" name="clickbankAds_clickbankId" />
                             </div>
                        </li>
                        <li>
                             <label>Secs</label>
                             <div>
                                 <input type="text" id="clickbankAds_secs" value="<?php echo $settings["clickbankAds_secs"]; ?>" name="clickbankAds_secs" />
                             </div>
                        </li>
                        <li>
                             <label>Orientation</label>
                             <div>
                                 <?php
                                 $o = $settings["clickbankAds_orientation"]; 
                                 ?>
                                 <select id="clickbankAds_orientation" name="clickbankAds_orientation">
                                       <option value="v" <?php echo $o=='v'?'selected':''; ?>>Vertical</option>
                                       <option value="h" <?php echo $o=='h'?'selected':''; ?>>Horizontal</option>
                                 </select>
                             </div>
                        </li>
                        <li>
                             <label>Number of ads</label>
                             <div>
                                 <input type="text" id="clickbankAds_numberOfAds" value="<?php echo $settings["clickbankAds_numberOfAds"]; ?>" name="clickbankAds_numberOfAds" />
                             </div>
                        </li>
                        <li>
                             <label>Width</label>
                             <div>
                                 <input type="text" id="clickbankAds_width" value="<?php echo $settings["clickbankAds_width"]; ?>" name="clickbankAds_width" />
                             </div>
                        </li>
                        <li>
                             <label>Height</label>
                             <div>
                                 <input type="text" id="clickbankAds_height" value="<?php echo $settings["clickbankAds_height"]; ?>" name="clickbankAds_height" />
                             </div>
                        </li>
